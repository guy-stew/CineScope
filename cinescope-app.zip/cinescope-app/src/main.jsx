import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'

// Bootstrap CSS
import 'bootstrap/dist/css/bootstrap.min.css'

// Leaflet CSS
import 'leaflet/dist/leaflet.css'
import 'leaflet.markercluster/dist/MarkerCluster.css'
import 'leaflet.markercluster/dist/MarkerCluster.Default.css'

// App styles
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
